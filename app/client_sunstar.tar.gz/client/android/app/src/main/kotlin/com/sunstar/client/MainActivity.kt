package com.sunstar.client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
