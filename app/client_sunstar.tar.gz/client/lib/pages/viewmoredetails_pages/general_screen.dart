import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../api_services/productdetail_api.dart';
import '../../model/productdetail_model.dart';
import 'package:google_fonts/google_fonts.dart';

class Product {
  final String label;
  final String value;

  Product({
    required this.label,
    required this.value,
  });
}

class GeneralScreen extends StatefulWidget {
  const GeneralScreen({super.key});

  @override
  State<GeneralScreen> createState() => _GeneralScreenState();
}

class _GeneralScreenState extends State<GeneralScreen> {
  List<Product> products = []; // Initialize an empty list of products.
  Map<String, String> generalData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    String productId = Get.arguments;
    getProductDetail(productId);
  }

  final ProductDetailService productDetails = ProductDetailService();

  getProductDetail(String productId) async {
    dynamic value = await productDetails.fetchProductById(productId);
    setState(() {
      // Assuming value is a ProductDetails instance with a 'general' property
      generalData = (value.general as Map<String, dynamic>)
          .map((key, value) => MapEntry(key, value.toString()));
      isLoading = false;
      print('General: $generalData');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: isLoading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : Padding(
              padding: const EdgeInsets.all(20.0),
              child: ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: generalData.entries.length,
                itemBuilder: (context, index) {
                  final entry = generalData.entries.elementAt(index);
                  Color backgroundColor =
                      index % 2 == 0 ? Color(0xFFFFFFFF) : Color(0xFFFBFAFA);

                  return Container(
                    width: double.infinity,
                    color: backgroundColor,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              entry.key, // Display the key.
                              style: GoogleFonts.roboto(
                                textStyle: const TextStyle(
                                  fontSize: 16,
                                  color: Colors.black54,
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 3,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              entry.value, // Display the value.
                              style: GoogleFonts.roboto(
                                textStyle: const TextStyle(
                                  fontSize: 16,
                                  color: Color(0xFF090F47),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }
}
