import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../api_services/productdetail_api.dart';

class Product {
  final String label;
  final String value;

  Product({
    required this.label,
    required this.value,
  });
}

class SpecificationScreen extends StatefulWidget {
  const SpecificationScreen({super.key});

  @override
  State<SpecificationScreen> createState() => _SpecificationScreenState();
}

class _SpecificationScreenState extends State<SpecificationScreen> {
  Map<String, Map<String, String>> specificationsData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    String productId = Get.arguments;
    getProductDetail(productId);
  }

  final ProductDetailService productDetails = ProductDetailService();

  getProductDetail(String productId) async {
    dynamic value = await productDetails.fetchProductById(productId);
    setState(() {
      specificationsData = (value.specifications as Map<String, dynamic>)
          .map((key, value) => MapEntry(key, (value as Map<String, dynamic>).map((k, v) => MapEntry(k, v.toString()))));
      isLoading = false;
      print('Specifications: $specificationsData');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: isLoading
          ? Center(child: CircularProgressIndicator()) // Show loading indicator
          : SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: specificationsData.entries.map((specEntry) {
              String category = specEntry.key; // e.g., "Warranty", "Performance"
              Map<String, String> attributes = specEntry.value;

              return Container(
                margin: const EdgeInsets.only(bottom: 8.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        category,
                        style: GoogleFonts.roboto(
                          textStyle: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                    ...attributes.entries.map((entry) {
                      Color backgroundColor =
                      attributes.entries.toList().indexOf(entry) % 2 == 0 ? Color(0xFFFFFFFF) : Color(0xFFFBFAFA);

                      return Container(
                        width: double.infinity,
                        color: backgroundColor,
                        padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              flex: 2,
                              child: Text(
                                entry.key, // Display the attribute key.
                                style: GoogleFonts.roboto(
                                  textStyle: const TextStyle(
                                    fontSize: 16,
                                    color: Colors.black54,
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(width: 20,),
                            Expanded(
                              flex: 3,
                              child: Text(
                                entry.value, // Display the attribute value.
                                style: GoogleFonts.roboto(
                                  textStyle: const TextStyle(
                                    fontSize: 16,
                                    color: Color(0xFF090F47),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ],
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
