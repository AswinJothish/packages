import 'package:flutter/material.dart';

class FilterScreen extends StatefulWidget {
  @override
  _FilterScreenState createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  String selectedBrand = 'Sunstar';
  List<String> capacityOptions = ['7L Below', '14.1L & Above'];
  List<String> selectedCapacities = [];
  List<String> typeOptions = ['Electrical & Non - storage', 'Electrical & storage'];
  List<String> selectedTypes = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF7F6F6),
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text('Filter', style: TextStyle(color: Colors.black)),
        backgroundColor: Color(0xFFF7F6F6),
        elevation: 0,
      ),
      body:
      Container(
        child: Column(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFF1C4E91))
                ),
                child: ListView(
                  children: [
                    Text('BRAND', style: TextStyle(fontWeight: FontWeight.bold)),
                    SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      children: ['Aqua', 'Sunstar', 'Products'].map((brand) {
                        return ChoiceChip(
                          label: Text(brand),
                          selected: selectedBrand == brand,
                          onSelected: (selected) {
                            setState(() {
                              selectedBrand = brand;
                            });
                          },
                        );
                      }).toList(),
                    ),
                    SizedBox(height: 16),
                    Text('CAPACITY', style: TextStyle(fontWeight: FontWeight.bold)),
                    ...capacityOptions.map((option) {
                      return CheckboxListTile(
                        title: Text(option),
                        value: selectedCapacities.contains(option),
                        onChanged: (value) {
                          setState(() {
                            if (value!) {
                              selectedCapacities.add(option);
                            } else {
                              selectedCapacities.remove(option);
                            }
                          });
                        },
                      );
                    }),
                    SizedBox(height: 16),
                    Text('TYPE', style: TextStyle(fontWeight: FontWeight.bold)),
                    ...typeOptions.map((option) {
                      return CheckboxListTile(
                        title: Text(option),
                        value: selectedTypes.contains(option),
                        onChanged: (value) {
                          setState(() {
                            if (value!) {
                              selectedTypes.add(option);
                            } else {
                              selectedTypes.remove(option);
                            }
                          });
                        },
                      );
                    }),
                  ],
                ),
              ),
            ),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16),
              child: ElevatedButton(
                child: Text('Apply Filter'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  padding: EdgeInsets.symmetric(vertical: 16),
                ),
                onPressed: () {
                  // Apply filter logic here
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}