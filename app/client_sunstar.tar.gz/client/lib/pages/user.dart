
class User {
  String? message;
  String? token;
  UserData? userData;
  bool? ok;

  User({this.message, this.token, this.userData, this.ok});

  User.fromJson(Map<String, dynamic> json) {
    message = json["message"];
    token = json["token"];
    userData = json["userData"] == null ? null : UserData.fromJson(json["userData"]);
    ok = json["ok"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["message"] = message;
    _data["token"] = token;
    if(userData != null) {
      _data["userData"] = userData?.toJson();
    }
    _data["ok"] = ok;
    return _data;
  }
}

class UserData {
  String? id;
  String? mobileNumber;
  String? role;
  String? username;
  List<DeliveryAddress>? deliveryAddress;
  String? userid;
  bool? active;

  UserData({this.id, this.mobileNumber, this.role, this.username, this.deliveryAddress, this.userid, this.active});

  UserData.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    mobileNumber = json["mobileNumber"];
    role = json["role"];
    username = json["username"];
    deliveryAddress = json["deliveryAddress"] == null ? null : (json["deliveryAddress"] as List).map((e) => DeliveryAddress.fromJson(e)).toList();
    userid = json["userid"];
    active = json["active"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["mobileNumber"] = mobileNumber;
    _data["role"] = role;
    _data["username"] = username;
    if(deliveryAddress != null) {
      _data["deliveryAddress"] = deliveryAddress?.map((e) => e.toJson()).toList();
    }
    _data["userid"] = userid;
    _data["active"] = active;
    return _data;
  }
}

class DeliveryAddress {
  Address? address;
  String? tag;
  String? id;

  DeliveryAddress({this.address, this.tag, this.id});

  DeliveryAddress.fromJson(Map<String, dynamic> json) {
    address = json["address"] == null ? null : Address.fromJson(json["address"]);
    tag = json["tag"];
    id = json["_id"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    if(address != null) {
      _data["address"] = address?.toJson();
    }
    _data["tag"] = tag;
    _data["_id"] = id;
    return _data;
  }
}

class Address {
  String? flatNumber;
  String? area;
  String? nearbyLandmark;
  String? receiverName;
  String? receiverMobileNumber;

  Address({this.flatNumber, this.area, this.nearbyLandmark, this.receiverName, this.receiverMobileNumber});

  Address.fromJson(Map<String, dynamic> json) {
    flatNumber = json["flatNumber"];
    area = json["area"];
    nearbyLandmark = json["nearbyLandmark"];
    receiverName = json["receiverName"];
    receiverMobileNumber = json["receiverMobileNumber"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["flatNumber"] = flatNumber;
    _data["area"] = area;
    _data["nearbyLandmark"] = nearbyLandmark;
    _data["receiverName"] = receiverName;
    _data["receiverMobileNumber"] = receiverMobileNumber;
    return _data;
  }
}