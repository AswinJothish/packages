import 'package:client/bottom_navigation.dart';
import 'package:client/pages/categories/categoryproduct_screen.dart';
import 'package:client/pages/addcart_page.dart';
import 'package:client/pages/home_page.dart';
import 'package:client/pages/login_screen.dart';
import 'package:client/pages/manage_address_page.dart';
import 'package:client/pages/order_page.dart';
import 'package:client/pages/productDetail_page.dart';
import 'package:client/pages/productViewall_page.dart';
import 'package:client/pages/product_preview.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'common/dio_client.dart';

void main() {
  ApiClient.initialize();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
        fontFamily: 'Satoshi'
      ),
      getPages: [
        GetPage(name: '/bottomNavigation', page: () => BottomNavigation()),
        GetPage(name: '/homeScreen', page: () => HomePage()),
        GetPage(name: '/productViewallpage', page: () => ProductviewallPage(isAscending: true,)),
        GetPage(name: '/categoryproductScreen', page: () => CategoryproductScreen(categoryName: '',)),
        GetPage(name: '/productdetailPage', page: () => ProductdetailPage(product: null,)),
        GetPage(name: '/addcart', page: () => AddcartPage()),
        GetPage(name: '/productPreview', page: () => ProductPreview()),
        GetPage(name: '/manageAddresspage', page: () => ManageAddressPage()),
        GetPage(name: '/orderPage', page: () => OrderPage())

      ],
      home: BottomNavigation(),
    );
  }
}
