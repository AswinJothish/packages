class AppConfig {
  static String appTitle = "Sun Star";
  static String appVersion = "1.0.0";

  // static String apiUrl = "http://65.0.108.35:4000/api/user"; // local
  // static String imageUrl = "http://65.0.108.35:4000/api/admin/files/view?key="; // local

  static String apiUrl = "https://sunstar.wenoxo.in/api/user"; // local
  static String imageUrl = "https://sunstar.wenoxo.in/api/admin/files/view?key="; // local

}
