class CategoryModel {
  String? message;
  bool? ok;
  List<CategoryData>? data;

  CategoryModel({this.message, this.ok, this.data});

  CategoryModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    ok = json['ok'];
    if (json['data'] != null) {
      data = <CategoryData>[];
      json['data'].forEach((v) {
        data!.add(new CategoryData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['ok'] = this.ok;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class CategoryData {
  String? sId;
  List<String>? category;
  int? iV;

  CategoryData({this.sId, this.category, this.iV});

  CategoryData.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    category = json['Category'].cast<String>();
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['Category'] = this.category;
    data['__v'] = this.iV;
    return data;
  }
}

