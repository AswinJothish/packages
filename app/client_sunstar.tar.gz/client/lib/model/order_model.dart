import '../contants/config.dart';

class OrderModel {
  String? message;
  List<Orders>? orders;
  bool? ok;

  OrderModel({this.message, this.orders, this.ok});

  OrderModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    if (json['orders'] != null) {
      orders = <Orders>[];
      json['orders'].forEach((v) {
        orders!.add(new Orders.fromJson(v));
      });
    }
    ok = json['ok'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    if (this.orders != null) {
      data['orders'] = this.orders!.map((v) => v.toJson()).toList();
    }
    data['ok'] = this.ok;
    return data;
  }
}

class Orders {
  String? sId;
  String? orderedBy;
  String? orderId;
  String? customerId;
  String? orderDate;
  DeliveryAddress? deliveryAddress;
  String? status;
  int? deliveryCharges;
  int? grandTotal;
  List<ProductsTQ>? products;
  String? createdAt;
  String? updatedAt;
  int? iV;
  String? transactionId;
  String? paymentImage;

  Orders(
      {this.sId,
        this.orderedBy,
        this.orderId,
        this.customerId,
        this.orderDate,
        this.deliveryAddress,
        this.status,
        this.deliveryCharges,
        this.grandTotal,
        this.products,
        this.createdAt,
        this.updatedAt,
        this.iV,
        this.transactionId,
        this.paymentImage});

  Orders.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    orderedBy = json['orderedBy'];
    orderId = json['orderId'];
    customerId = json['customerId'];
    orderDate = json['orderDate'];
    deliveryAddress = json['deliveryAddress'] != null
        ? new DeliveryAddress.fromJson(json['deliveryAddress'])
        : null;
    status = json['status'];
    deliveryCharges = json['deliveryCharges'];
    grandTotal = json['grandTotal'];
    if (json['products'] != null) {
      products = <ProductsTQ>[];
      json['products'].forEach((v) {
        products!.add(new ProductsTQ.fromJson(v));
      });
    }
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
    transactionId = json['transactionId'];
    paymentImage = json['paymentImage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['orderedBy'] = this.orderedBy;
    data['orderId'] = this.orderId;
    data['customerId'] = this.customerId;
    data['orderDate'] = this.orderDate;
    if (this.deliveryAddress != null) {
      data['deliveryAddress'] = this.deliveryAddress!.toJson();
    }
    data['status'] = this.status;
    data['deliveryCharges'] = this.deliveryCharges;
    data['grandTotal'] = this.grandTotal;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['__v'] = this.iV;
    data['transactionId'] = this.transactionId;
    data['paymentImage'] = this.paymentImage;
    return data;
  }
}

class DeliveryAddress {
  tagName? home;

  DeliveryAddress({this.home});

  DeliveryAddress.fromJson(Map<String, dynamic> json) {
    home = json['home'] != null ? new tagName.fromJson(json['home']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.home != null) {
      data['home'] = this.home!.toJson();
    }
    return data;
  }
}

class tagName {
  String? flatNumber;
  String? area;
  String? nearbyLandmark;
  String? receiverName;
  String? receiverMobileNumber;

  tagName(
      {this.flatNumber,
        this.area,
        this.nearbyLandmark,
        this.receiverName,
        this.receiverMobileNumber});

  tagName.fromJson(Map<String, dynamic> json) {
    flatNumber = json['flatNumber'];
    area = json['area'];
    nearbyLandmark = json['nearbyLandmark'];
    receiverName = json['receiverName'];
    receiverMobileNumber = json['receiverMobileNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['flatNumber'] = this.flatNumber;
    data['area'] = this.area;
    data['nearbyLandmark'] = this.nearbyLandmark;
    data['receiverName'] = this.receiverName;
    data['receiverMobileNumber'] = this.receiverMobileNumber;
    return data;
  }
}

class ProductsTQ {
  ProductId? productId;
  int? quantity;
  String? sId;

  ProductsTQ({this.productId, this.quantity, this.sId});

  ProductsTQ.fromJson(Map<String, dynamic> json) {
    productId = json['productId'] != null
        ? new ProductId.fromJson(json['productId'])
        : null;
    quantity = json['quantity'];
    sId = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.productId != null) {
      data['productId'] = this.productId!.toJson();
    }
    data['quantity'] = this.quantity;
    data['_id'] = this.sId;
    return data;
  }
}

class ProductId {
  String? sId;
  String? productName;
  List<String>? productImages;
  int? customerPrice;
  int? dealerPrice;

  ProductId(
      {this.sId, this.productName, this.productImages, this.customerPrice,this.dealerPrice});

  ProductId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    productName = json['productName'];
    productImages = json['productImages'].cast<String>();
    customerPrice = json['customerPrice'];
    dealerPrice =json ['dealerPrice'];
  }

  String get fullImageUrl {
    if (productImages != null && productImages!.isNotEmpty) {
      return '${AppConfig.imageUrl}${productImages![0]}';
    } else {
      return '${AppConfig.imageUrl}admin/files/view?key=default_image/';
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['productName'] = this.productName;
    data['productImages'] = this.productImages;
    data['customerPrice'] = this.customerPrice;
    data['dealerPrice'] = this.dealerPrice;
    return data;
  }
}
