import 'package:client/contants/config.dart';
import 'package:client/model/productdetail_model.dart';

class ProductList {
  String? message;
  bool? ok;
  List<Products>? products;
  int? total;

  ProductList({this.message, this.ok, this.products, this.total});

  ProductList.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    ok = json['ok'];
    if (json['products'] != null) {
      products = List<Products>.from(json['products'].map((v) => Products.fromJson(v)));
    }
    total = json['total'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['message'] = message;
    data['ok'] = ok;
    if (products != null) {
      data['products'] = products!.map((v) => v.toJson()).toList();
    }
    data['total'] = total;
    return data;
  }
}

class Products {
  String? sId;
  String? productName;
  String? productCode;
  List<String>? productImages;
  String? description;
  int? purchasedPrice;
  int? customerPrice;
  String? brand;
  int? dealerPrice;
  int? strikePrice;
  bool? active;
  Specifications? specifications;
  General? general;
  String? category;
  String? createdAt;
  String? updatedAt;
  int? stock;
  int? iV;
  List<Offers>? offers;

  Products({
    this.sId,
    this.productName,
    this.productCode,
    this.productImages,
    this.description,
    this.purchasedPrice,
    this.customerPrice,
    this.brand,
    this.dealerPrice,
    this.strikePrice,
    this.active,
    this.specifications,
    this.general,
    this.category,
    this.createdAt,
    this.updatedAt,
    this.stock,
    this.iV,
    this.offers
  });

  Products.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    productName = json['productName'];
    productCode = json['productCode'];
    productImages =
    // json['productImages'] != null ? List<String>.from(json['productImages']) : null;
    json['productImages'] != null
        ? List<String>.from(json['productImages'].map((image) => image?.toString() ?? ''))
        : [];
    description = json['description'];
    purchasedPrice = json['purchasedPrice'];
    customerPrice = json['customerPrice'];
    brand = json['brand'];
    dealerPrice = json['dealerPrice'];
    strikePrice = json['strikePrice'];
    active = json['active'];
    specifications = json['specifications'] != null
        ? Specifications.fromJson(json['specifications'])
        : null;
    general =
    json['general'] != null ? new General.fromJson(json['general']) : null;
    category = json['category'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    stock = json['stock'];
    iV = json['__v'];
    offers = json["offers"] == null ? null : (json["offers"] as List).map((e) => Offers.fromJson(e)).toList();
  }

  // Getter to return the first image URL with the full path
  String get fullImageUrl {
    if (productImages != null && productImages!.isNotEmpty) {
      return '${AppConfig.imageUrl}${productImages![0]}';
    } else {
      return '${AppConfig.imageUrl}admin/files/view?key=default_image/';
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['_id'] = sId;
    data['productName'] = productName;
    data['productCode'] = productCode;
    data['productImages'] = productImages;
    data['description'] = description;
    data['purchasedPrice'] = purchasedPrice;
    data['customerPrice'] = customerPrice;
    data['brand'] = brand;
    data['dealerPrice'] = dealerPrice;
    data['strikePrice'] = strikePrice;
    data['active'] = active;
    if (specifications != null) {
      data['specifications'] = specifications!.toJson();
    }
    if (this.general != null) {
      data['general'] = this.general!.toJson();
    }
    data['category'] = this.category;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    data['stock'] = stock;
    data['__v'] = iV;
    if(offers != null) {
      data["offers"] = offers?.map((e) => e.toJson()).toList();
    }
    return data;
  }
}

class Offers {
  int? from;
  int? to;
  int? customerPrice;
  int? dealerPrice;

  Offers({this.from, this.to, this.customerPrice, this.dealerPrice});

  Offers.fromJson(Map<String, dynamic> json) {
    from = json["from"];
    to = json["to"];
    customerPrice = json["customerPrice"];
    dealerPrice = json["dealerPrice"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["from"] = from;
    _data["to"] = to;
    _data["customerPrice"] = customerPrice;
    _data["dealerPrice"] = dealerPrice;
    return _data;
  }
}


class Specifications {
  Warranty? warranty;
  Performance? performance;
  General? general;

  Specifications({this.warranty, this.performance, this.general});

  Specifications.fromJson(Map<String, dynamic> json) {
    warranty = json['Warranty'] != null ? Warranty.fromJson(json['Warranty']) : null;
    performance = json['Performance'] != null ? Performance.fromJson(json['Performance']) : null;
    general = json['General'] != null ? General.fromJson(json['General']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (warranty != null) {
      data['Warranty'] = warranty!.toJson();
    }
    if (performance != null) {
      data['Performance'] = performance!.toJson();
    }
    if (general != null) {
      data['General'] = general!.toJson();
    }
    return data;
  }
}

class Warranty {
  String? warrantySummary;
  String? warrantyServiceType;
  String? notCoveredInWarranty;
  String? warrantyCoverage;

  Warranty({
    this.warrantySummary,
    this.warrantyServiceType,
    this.notCoveredInWarranty,
    this.warrantyCoverage,
  });

  Warranty.fromJson(Map<String, dynamic> json) {
    warrantySummary = json['Warranty Summary'];
    warrantyServiceType = json['Warranty Service Type'];
    notCoveredInWarranty = json['Not Covered in Warranty'];
    warrantyCoverage = json['Warranty Coverage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Warranty Summary'] = warrantySummary;
    data['Warranty Service Type'] = warrantyServiceType;
    data['Not Covered in Warranty'] = notCoveredInWarranty;
    data['Warranty Coverage'] = warrantyCoverage;
    return data;
  }
}

class Performance {
  String? filtrationCapacity;
  String? purificationCapacity;
  String? installationMethod;
  String? powerConsumption;

  Performance({
    this.filtrationCapacity,
    this.purificationCapacity,
    this.installationMethod,
    this.powerConsumption,
  });

  Performance.fromJson(Map<String, dynamic> json) {
    filtrationCapacity = json['Filtration capacity'];
    purificationCapacity = json['Purification Capacity'];
    installationMethod = json['Installation Method'];
    powerConsumption = json['Power Consumption'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Filtration capacity'] = filtrationCapacity;
    data['Purification Capacity'] = purificationCapacity;
    data['Installation Method'] = installationMethod;
    data['Power Consumption'] = powerConsumption;
    return data;
  }
}

class General {
  String? model;
  String? color;

  General({this.model, this.color});

  General.fromJson(Map<String, dynamic> json) {
    model = json['Model'];
    color = json['Color'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['Model'] = model;
    data['Color'] = color;
    return data;
  }
}


class GeneralType {
  String? capacity;
  String? type;

  GeneralType({this.capacity, this.type});

  GeneralType.fromJson(Map<String, dynamic> json) {
    capacity = json['Capacity'];
    type = json['Type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Capacity'] = this.capacity;
    data['Type'] = this.type;
    return data;
  }
}
