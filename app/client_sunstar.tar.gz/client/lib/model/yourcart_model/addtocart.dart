
//add to cart model

class addtocart {
  int? status;
  String? message;
  List<AddCart>? cart;

  addtocart({this.status, this.message, this.cart});

  addtocart.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['cart'] != null) {
      cart = <AddCart>[];
      json['cart'].forEach((v) {
        cart!.add(new AddCart.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.cart != null) {
      data['cart'] = this.cart!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AddCart {
  String? productId;
  int? quantity;
  String? sId;

  AddCart({this.productId, this.quantity, this.sId});

  AddCart.fromJson(Map<String, dynamic> json) {
    productId = json['productId'];
    quantity = json['quantity'];
    sId = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['productId'] = this.productId;
    data['quantity'] = this.quantity;
    data['_id'] = this.sId;
    return data;
  }
}
