
//get cart item model

import '../../contants/config.dart';


class GetCartItem {
  int? status;
  List<GetCart>? cart;

  GetCartItem({this.status, this.cart});

  GetCartItem.fromJson(Map<String, dynamic> json) {
    status = json["status"];
    cart = json["cart"] == null ? null : (json["cart"] as List).map((e) => GetCart.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["status"] = status;
    if(cart != null) {
      _data["cart"] = cart?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class GetCart {
  ProductId? productId;
  int? quantity;
  String? id;

  GetCart({this.productId, this.quantity, this.id});

  GetCart.fromJson(Map<String, dynamic> json) {
    productId = json["productId"] == null ? null : ProductId.fromJson(json["productId"]);
    quantity = json["quantity"];
    id = json["_id"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    if(productId != null) {
      _data["productId"] = productId?.toJson();
    }
    _data["quantity"] = quantity;
    _data["_id"] = id;
    return _data;
  }
}

class ProductId {
  String? id;
  String? productName;
  String? productCode;
  List<String>? productImages;
  int? customerPrice;
  int? stock;
  int? dealerPrice;
  String? brand;
  int? strikePrice;
  List<Offers>? offers;

  ProductId({this.id, this.productName, this.productCode, this.productImages, this.customerPrice,this.dealerPrice, this.stock, this.brand, this.strikePrice, this.offers});

  ProductId.fromJson(Map<String, dynamic> json) {
    id = json["_id"];
    productName = json["productName"];
    productCode = json["productCode"];
    productImages = json["productImages"] == null ? null : List<String>.from(json["productImages"]);
    customerPrice = json["customerPrice"];
    dealerPrice = json["dealerPrice"];
    stock = json["stock"];
    brand = json["brand"];
    strikePrice = json["strikePrice"];
    offers = json["offers"] == null ? null : (json["offers"] as List).map((e) => Offers.fromJson(e)).toList();
  }


  // Getter to return the first image URL with the full path
  String get fullImageUrl {
    if (productImages != null && productImages!.isNotEmpty) {
      return '${AppConfig.imageUrl}${productImages![0]}';
    } else {
      return '${AppConfig.imageUrl}admin/files/view?key=default_image/';
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["_id"] = id;
    _data["productName"] = productName;
    _data["productCode"] = productCode;
    if(productImages != null) {
      _data["productImages"] = productImages;
    }
    _data["customerPrice"] = customerPrice;
    _data["dealerPrice"] = dealerPrice;
    _data["stock"] = stock;
    _data["brand"] = brand;
    _data["strikePrice"] = strikePrice;
    if(offers != null) {
      _data["offers"] = offers?.map((e) => e.toJson()).toList();
    }
    return _data;
  }
}

class Offers {
  int? from;
  int? to;
  int? customerPrice;
  int? dealerPrice;

  Offers({this.from, this.to, this.customerPrice, this.dealerPrice});

  Offers.fromJson(Map<String, dynamic> json) {
    from = json["from"];
    to = json["to"];
    customerPrice = json["customerPrice"];
    dealerPrice = json["dealerPrice"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["from"] = from;
    _data["to"] = to;
    _data["customerPrice"] = customerPrice;
    _data["dealerPrice"] = dealerPrice;
    return _data;
  }
}



