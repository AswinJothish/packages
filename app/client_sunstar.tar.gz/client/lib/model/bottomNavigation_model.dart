import 'dart:ui';

class BottomNavigationmodel {
  late String selectedimg;
  late String unselectedimg;
  late String text1;
  late Color clrs;

  BottomNavigationmodel(this.selectedimg, this.unselectedimg, this.text1, this.clrs);
}
