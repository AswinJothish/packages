class ProductDetailscart {
  final String name;
  final String brand;
  final String gst;
  final String price;
  final String discountPrice;
  final String quantity;

  ProductDetailscart({
    required this.name,
    required this.brand,
    required this.gst,
    required this.price,
    required this.discountPrice,
    required this.quantity,
  });
}
