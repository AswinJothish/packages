import '../contants/config.dart';

class OrderEditModel {
  String? message;
  bool? ok;
  Order? order;

  OrderEditModel({this.message, this.ok, this.order});

  OrderEditModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    ok = json['ok'];
    order = json['order'] != null ? new Order.fromJson(json['order']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    data['ok'] = this.ok;
    if (this.order != null) {
      data['order'] = this.order!.toJson();
    }
    return data;
  }
}

class Order {
  String? sId;
  String? orderedBy;
  String? orderId;
  CustomerId? customerId;
  String? orderDate;
  DeliveryAddress? deliveryAddress;
  String? status;
  int? deliveryCharges;
  int? grandTotal;
  List<ProductsQ>? products;
  String? createdAt;
  String? updatedAt;
  int? iV;
  String? editedDate;
  List<Payment>? payment;
  List<PaymentDetails>? paymentDetails;

  Order(
      {this.sId,
        this.orderedBy,
        this.orderId,
        this.customerId,
        this.orderDate,
        this.deliveryAddress,
        this.status,
        this.deliveryCharges,
        this.grandTotal,
        this.products,
        this.createdAt,
        this.updatedAt,
        this.iV,
        this.editedDate,
        this.payment,
        this.paymentDetails
        });

  Order.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    orderedBy = json['orderedBy'];
    orderId = json['orderId'];
    customerId = json['customerId'] != null
        ? new CustomerId.fromJson(json['customerId'])
        : null;
    orderDate = json['orderDate'];
    deliveryAddress = json['deliveryAddress'] != null
        ? new DeliveryAddress.fromJson(json['deliveryAddress'])
        : null;
    status = json['status'];
    deliveryCharges = json['deliveryCharges'];
    grandTotal = json['grandTotal'];
    if (json['products'] != null) {
      products = <ProductsQ>[];
      json['products'].forEach((v) {
        products!.add(new ProductsQ.fromJson(v));
      });
    }
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
    editedDate = json["EditedDate"];
    payment = json["payment"] == null ? null : (json["payment"] as List).map((e) => Payment.fromJson(e)).toList();
    paymentDetails = json["paymentDetails"] == null ? null : (json["paymentDetails"] as List).map((e) => PaymentDetails.fromJson(e)).toList();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['orderedBy'] = this.orderedBy;
    data['orderId'] = this.orderId;
    if (this.customerId != null) {
      data['customerId'] = this.customerId!.toJson();
    }
    data['orderDate'] = this.orderDate;
    if (this.deliveryAddress != null) {
      data['deliveryAddress'] = this.deliveryAddress!.toJson();
    }
    data['status'] = this.status;
    data['deliveryCharges'] = this.deliveryCharges;
    data['grandTotal'] = this.grandTotal;
    if (this.products != null) {
      data['products'] = this.products!.map((v) => v.toJson()).toList();
    }
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['__v'] = this.iV;
    data["EditedDate"] = editedDate;
    if(payment != null) {
      data["payment"] = payment?.map((e) => e.toJson()).toList();
    }
    if(paymentDetails != null) {
      data["paymentDetails"] = paymentDetails?.map((e) => e.toJson()).toList();
    }
    return data;
  }
}

class PaymentDetails {
  String? date;
  dynamic paymentImage;
  dynamic transactionId;
  String? mode;
  int? paidAmount;
  int? balanceAmount;
  String? id;
  String? createdAt;
  String? updatedAt;

  PaymentDetails({this.date, this.paymentImage, this.transactionId, this.mode, this.paidAmount, this.balanceAmount, this.id, this.createdAt, this.updatedAt});

  PaymentDetails.fromJson(Map<String, dynamic> json) {
    date = json["date"];
    paymentImage = json["paymentImage"];
    transactionId = json["transactionId"];
    mode = json["mode"];
    paidAmount = json["paidAmount"];
    balanceAmount = json["balanceAmount"];
    id = json["_id"];
    createdAt = json["createdAt"];
    updatedAt = json["updatedAt"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["date"] = date;
    _data["paymentImage"] = paymentImage;
    _data["transactionId"] = transactionId;
    _data["mode"] = mode;
    _data["paidAmount"] = paidAmount;
    _data["balanceAmount"] = balanceAmount;
    _data["_id"] = id;
    _data["createdAt"] = createdAt;
    _data["updatedAt"] = updatedAt;
    return _data;
  }
}

class Payment {
  String? paymentImage;
  String? transactionId;
  dynamic cash;
  String? verified;
  String? id;

  Payment({this.paymentImage, this.transactionId, this.cash, this.verified, this.id});

  Payment.fromJson(Map<String, dynamic> json) {
    paymentImage = json["paymentImage"];
    transactionId = json["transactionId"];
    cash = json["cash"];
    verified = json["verified"];
    id = json["_id"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["paymentImage"] = paymentImage;
    _data["transactionId"] = transactionId;
    _data["cash"] = cash;
    _data["verified"] = verified;
    _data["_id"] = id;
    return _data;
  }
}

class CustomerId {
  String? sId;
  String? username;
  String? mobileNumber;

  CustomerId({this.sId, this.username, this.mobileNumber});

  CustomerId.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    username = json['username'];
    mobileNumber = json['mobileNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['username'] = this.username;
    data['mobileNumber'] = this.mobileNumber;
    return data;
  }
}

class DeliveryAddress {
  Home? home;

  DeliveryAddress({this.home});

  DeliveryAddress.fromJson(Map<String, dynamic> json) {
    home = json['home'] != null ? new Home.fromJson(json['home']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.home != null) {
      data['home'] = this.home!.toJson();
    }
    return data;
  }
}

class Home {
  String? flatNumber;
  String? area;
  String? nearbyLandmark;
  String? receiverName;
  String? receiverMobileNumber;

  Home(
      {this.flatNumber,
        this.area,
        this.nearbyLandmark,
        this.receiverName,
        this.receiverMobileNumber});

  Home.fromJson(Map<String, dynamic> json) {
    flatNumber = json['flatNumber'];
    area = json['area'];
    nearbyLandmark = json['nearbyLandmark'];
    receiverName = json['receiverName'];
    receiverMobileNumber = json['receiverMobileNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['flatNumber'] = this.flatNumber;
    data['area'] = this.area;
    data['nearbyLandmark'] = this.nearbyLandmark;
    data['receiverName'] = this.receiverName;
    data['receiverMobileNumber'] = this.receiverMobileNumber;
    return data;
  }
}

class ProductsQ {
  ProductIdmodel? productId;
  int? quantity;
  String? sId;

  ProductsQ({this.productId, this.quantity, this.sId});

  ProductsQ.fromJson(Map<String, dynamic> json) {
    productId = json['productId'] != null
        ? new ProductIdmodel.fromJson(json['productId'])
        : null;
    quantity = json['quantity'];
    sId = json['_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.productId != null) {
      data['productId'] = this.productId!.toJson();
    }
    data['quantity'] = this.quantity;
    data['_id'] = this.sId;
    return data;
  }
}

class ProductIdmodel {
  String? sId;
  String? productName;
  String? productCode;
  List<String>? productImages;
  int? customerPrice;
  int? dealerPrice;
  String? brand;
  int? strikePrice;
  List<Offers>? offers;

  ProductIdmodel(
      {this.sId,
        this.productName,
        this.productCode,
        this.productImages,
        this.customerPrice,
        this.dealerPrice,
        this.brand,
        this.strikePrice,
        this.offers
      });

  ProductIdmodel.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    productName = json['productName'];
    productCode = json['productCode'];
    productImages = json['productImages'].cast<String>();
    customerPrice = json['customerPrice'];
    dealerPrice = json['dealerPrice'];
    brand = json['brand'];
    strikePrice = json['strikePrice'];
    offers = json["offers"] == null ? null : (json["offers"] as List).map((e) => Offers.fromJson(e)).toList();
  }

  String get fullImageUrl {
    if (productImages != null && productImages!.isNotEmpty) {
      return '${AppConfig.imageUrl}${productImages![0]}';
    } else {
      return '${AppConfig.imageUrl}admin/files/view?key=default_image/';
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['productName'] = this.productName;
    data['productCode'] = this.productCode;
    data['productImages'] = this.productImages;
    data['customerPrice'] = this.customerPrice;
    data['dealerPrice'] = this.dealerPrice;
    data['brand'] = this.brand;
    data['strikePrice'] = this.strikePrice;
    if(offers != null) {
      data["offers"] = offers?.map((e) => e.toJson()).toList();
    }
    return data;
  }
}

class Offers {
  int? from;
  int? to;
  int? customerPrice;
  int? dealerPrice;

  Offers({this.from, this.to, this.customerPrice, this.dealerPrice});

  Offers.fromJson(Map<String, dynamic> json) {
    from = json["from"];
    to = json["to"];
    customerPrice = json["customerPrice"];
    dealerPrice = json["dealerPrice"];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> _data = <String, dynamic>{};
    _data["from"] = from;
    _data["to"] = to;
    _data["customerPrice"] = customerPrice;
    _data["dealerPrice"] = dealerPrice;
    return _data;
  }
}

