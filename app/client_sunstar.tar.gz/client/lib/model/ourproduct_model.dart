class OurproductModel {
  final String productImage;
  final String productName;
  final String rate;
  final String text1;
  final String text2;

  OurproductModel(
      this.productImage, this.productName, this.rate, this.text1, this.text2);
}
